FILE:

api/analyze/inc.functions.php
Line 6
API Google

api/analyze/inc.functions.php
Line 41
API Google JSON config.json

api/bot/inc.functions.php
Line 27
API Google

api/chat-bot/inc.functions.php
Line 27
API Google

api/chat-bot/inc.functions.php
Line 41
API Google JSON config.json

api/config/inc.functions.php
Line 37
TWITCH Username bot

api/config/inc.functions.php
Line 38
TWITCH Password oath

api/config/inc.functions.php
Line 63
TWITCH Username bot

api/config/inc.functions.php
Line 64
TWITCH Password oath

api/includes/inc.api.php
Line 2
RABBITMQ data

api/includes/inc.api.php
Line 34
MYSQL data

api/includes/inc.api.php
Line 114
TWITCH data