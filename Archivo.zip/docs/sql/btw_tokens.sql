INSERT INTO `btw_tokens` (`auto_id`, `access_token`, `expires_in`, `token_type`) VALUES (1, 'token', 0, 'bearer');
